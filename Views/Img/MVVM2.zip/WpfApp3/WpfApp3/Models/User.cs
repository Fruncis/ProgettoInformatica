﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3.Models
{
    internal class User
    {//notare come in C# è possibile scrivere tutta la classe in un solo file grazie alle abbreviazioni utilizzate con { get; set; }
        public User(int id, string name, string email)
        {
            Id = id;
            Name = name;
            Email = email;
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        //le istruzioni qua sopra sono l'equivalente di:
        //private int _id;
        //public string getId() { return _id; }
        //private string _name;
        //public string getName() { return _name; }
        //private string _email;
        //public string getEmail() { return _email;}

    }
}
