﻿using System.Windows;

namespace WpfApp3
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow() //quando il progetto si fa complesso è meglio spostare la logica di partenza nel file di App.cs...
        {
            //MVVM pattern => model view - view model
            //importante, per creare il collegamento con il "cervello" associato a questa View, ovvero per creare il collegamento con il suo ViewModel, creo un attributo del tipo ViewModel di riferimento, in questo caso di tipo MainWindowViewModel
            //var viewModel = new MainWindowViewModel() //per usare anche il model, posso creare e passare delle classi a parte qua, per esempio con var viewModel = new MainWindowViewModel(new User("mario","rossi",32));
            //{
            //    //FirstName = "Kevin"
            //};

            //this.DataContext = viewModel; //dopodiché creo il collegamento del DataContext della view con il ViewModel creato precedentemente => ora ho collegato View con ViewModel
            InitializeComponent();

            //queste due istruzioni le usavo insieme al primo step in MainWindowViewModel...scomodo!
            //viewModel.FirstName = "Mark";
            //viewModel.OnPropertyChanged(nameof(MainWindowViewModel.FirstName));
        }

        //questo è un metodo generato in automatico quando per esempio faccio doppio click su un button nella view... questo non lo voglio! voglio la gestione degli eventi separati dalla view! => MVVM pattern
        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
