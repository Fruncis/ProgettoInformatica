﻿using System.Windows.Input;
using WpfApp3.Commands;
using WpfApp3.Stores;

namespace WpfApp3.ViewModels
{
    internal class OtherViewModel2 : ViewModelBase
    {
        public ICommand ChangeView { get; }

        public OtherViewModel2(NavigationStore ns)
        {
            //il comando ChangeView ogni volta che viene premuto mi porta nella ViewModel1
            ChangeView = new NavigationCommand<OtherViewModel>(ns, () => new OtherViewModel(ns));
        }
    }
}
