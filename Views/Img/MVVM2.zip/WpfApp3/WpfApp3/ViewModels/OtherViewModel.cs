﻿using System.Windows.Input;
using WpfApp3.Commands;
using WpfApp3.Stores;

namespace WpfApp3.ViewModels
{
    internal class OtherViewModel : ViewModelBase
    {
        public ICommand ChangeView { get; }

        public OtherViewModel(NavigationStore ns)
        {
            //il comando ChangeView ogni volta che viene premuto mi porta nella ViewModel2 
            ChangeView = new NavigationCommand<OtherViewModel2>(ns, () => new OtherViewModel2(ns));
        }
    }
}
