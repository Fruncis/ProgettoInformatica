﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfApp3.ViewModels
{//questa classe che implementa l'interfaccia Inotify serve per evitare di scrivere sempre il metodo lungo per aggiornare le views di un cambiamento
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T field, T newValue, [CallerMemberName] string propertyName = null)
        {
            if (!EqualityComparer<T>.Default.Equals(field, newValue))
            {
                field = newValue;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
                return true;
            }
            return false;
        }
        //approfondimento sulle dependecy object e sul design mode per usare dei dati di test
        protected bool IsInDesignMode()
        {
            return DesignerProperties.GetIsInDesignMode(new System.Windows.DependencyObject());
        }
    }
}

