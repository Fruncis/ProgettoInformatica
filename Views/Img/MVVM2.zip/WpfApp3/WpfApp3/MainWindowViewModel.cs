﻿using System.Windows.Input;
using WpfApp3.Commands;
using WpfApp3.Models;
using WpfApp3.Stores;
using WpfApp3.ViewModels;

namespace WpfApp3
{
    //creo il ViewModel della finestra inziale e la faccio ereditare da ViewModelBase, una classe che gestisce gli eventi per notificare tutti delle modifiche per aggiornare la grafica in tempo reale
    internal class MainWindowViewModel : ViewModelBase
    {
        private readonly NavigationStore store; //variabili per memorizzare il viewModel corrente
        public ViewModelBase CurrentViewModel => store.CurrentViewModel; //variabili per memorizzare il viewModel corrente
        //il model
        private readonly User utente;
        //private User user; //esempio per il model associato... guarda il costruttore sotto
        //creo il binding tra le view in MainWindow e le proprietà gestite qua in MainWindowViewModel
        private string _firstName;
        public string FirstName //questo nome deve essere IDENTICO al binding associato in MainWindow
        {
            get => _firstName;
            set => SetProperty(ref _firstName, value);
        }

        //altri binding
        private string _buttonContent;
        public string ButtonContent
        {
            get => _buttonContent;
            set => SetProperty(ref _buttonContent, value);
        }
        public ICommand ChangeNameCommand { get; } //il comando scritto identico come attributo nella view! andare a guardare la sua view .xaml per credere!
        public ICommand AbilitaIlChangeNameCommand { get; } //altro comando

        public MainWindowViewModel() 
        {              
            //qua sotto imposto la variabile che mi salverà la view corrente
            store = new NavigationStore();
            store.CurrentViewModel = new OtherViewModel(store);
            store.CurrentViewModelChanged += OnCurrentViewModelChanged; //per aggiornare il cambio di view al programma
            //creo e imposto il model
            utente = new User(1, "mario", "mario@live.it");
            _firstName = utente.Name;

            //faccio il binding con i command dei button nella view
            ChangeNameCommand = new ChangeNameCommand(this);
            AbilitaIlChangeNameCommand = new AbilitaIlChangeNameCommand(this);

            //approfondimento per lavorare con dei dati di test
            if (IsInDesignMode())
            { 
                //lavora con dei dati di test per vedere l'anteprima nella View!
                _buttonContent = "provaa"; //guardate in anteprima in MainWindow.xaml!
            }
            else
            {
                //altrimenti con IsDesignTimeCreatable=False in MainWindow.xaml => se devi prendere dei dati da fonti esterne (per esempio più pesanti)
                _buttonContent = "dato realee"; //questo si vede quando parte effettivamente il programma
            }

        }

        private void OnCurrentViewModelChanged()
        {
            OnPropertyChanged(nameof(CurrentViewModel)); //aggiorno il programma che la view è stata modificata
        }
    }
}
