﻿using System;
using WpfApp3.ViewModels;

namespace WpfApp3.Stores
{ //classe che salva la view corrente e l'azione per aggiornare il softare della modifica della view!
    internal class NavigationStore
    {
        public event Action CurrentViewModelChanged;
        private ViewModelBase _currentViewModel;
        public ViewModelBase CurrentViewModel
        {
            get { return _currentViewModel; }
            set {
                
                _currentViewModel = value;
                OnCurrentViewModelChanged();         
            }
        }

        private void OnCurrentViewModelChanged()
        {
            CurrentViewModelChanged?.Invoke();
        }
    }
}
