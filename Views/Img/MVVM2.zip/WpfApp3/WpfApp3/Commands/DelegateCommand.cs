﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp3.Commands
{//classe "helper" per gestire gli eventi su delle view, come per esempio => cosa succede quando premi un button? si può effettivamente premere il button?
    internal abstract class DelegateCommand : ICommand
    {

        //implementazione dei metodi dell'interfaccia ICommand con quello che gli passi tu
        public abstract void Execute(object parameter); // => _executeAction(parameter);

        public virtual bool CanExecute(object parameter) => true;

        public event EventHandler CanExecuteChanged;

        public virtual void InvokeCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }
}
