﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3.Commands
{
    internal class AbilitaIlChangeNameCommand : MainWindowCommand
    {  
        public AbilitaIlChangeNameCommand(MainWindowViewModel mainWindowViewModel) : base(mainWindowViewModel)
        {
        }

        public override void Execute(object parameter) //quello che esegue il button della MainWindow
        {
            base.MainWindowViewModel.FirstName = ""; //abilito il bottone
            ChangeNameCommand _cCommand = (ChangeNameCommand)base.MainWindowViewModel.ChangeNameCommand;
            _cCommand.InvokeCanExecuteChanged();
        }
    }
}
