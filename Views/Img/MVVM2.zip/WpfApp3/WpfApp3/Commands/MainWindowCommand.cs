﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3.Commands
{
    internal abstract class MainWindowCommand : DelegateCommand //visto che abilita e changename command hanno la viewModel in comune come attributo... ho creato la loro classe padre con questo attributo in comune!
    {
        public MainWindowViewModel MainWindowViewModel { get; set; }

        public MainWindowCommand(MainWindowViewModel mainWindowViewModel)
        {
            MainWindowViewModel = mainWindowViewModel;
        }
    }
}
