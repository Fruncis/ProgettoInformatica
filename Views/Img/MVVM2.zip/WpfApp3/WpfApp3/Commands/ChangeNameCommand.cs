﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp3.Commands
{
    internal class ChangeNameCommand : MainWindowCommand
    {
        public ChangeNameCommand(MainWindowViewModel mainWindowViewModel) : base(mainWindowViewModel)
        {
        }

        public override void Execute(object parameter) //quello che esegue il button della MainWindow
        {
            base.MainWindowViewModel.FirstName = "Walter"; //cambio il contenuto di FirstName in Walter
            this.InvokeCanExecuteChanged(); //questo metodo mi chiamerà in automatico quello che ho definito sottostante!
        }

        public override bool CanExecute(object parameter)
        {
            //Console.WriteLine("text"); //se aprite la console potete verificare quando viene chiamato questo metodo
            return base.MainWindowViewModel.FirstName != "Walter"; //posso premere sul bottone quando il testo è diverso da Walter => in pratica, una volta cliccato non potrei più ricliccarlo! MA! ho aggiunto AbilitaIlChangeName per cambiare questa condizione!
        }

    }
}
