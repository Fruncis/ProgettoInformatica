﻿using System;
using WpfApp3.Stores;
using WpfApp3.ViewModels;

namespace WpfApp3.Commands
{ //la classe con il comando che mi permette di navigare tra le views...
    internal class NavigationCommand<T> : DelegateCommand where T : ViewModelBase
    {
        public NavigationStore NavigationStore { get; set; }
        public Func<T> NavigationAction { get; set; } //questo attributo è di tipo generico! così posso passare tutti i tipi di viewModel che voglio!!! se no avrei dovuto creare una classe command per ogni viewModel che volevo selezionare...
        public NavigationCommand(NavigationStore ns, Func<T> na)
        {
            NavigationStore = ns;
            NavigationAction = na;
        }

        public override void Execute(object parameter)
        {
            NavigationStore.CurrentViewModel = NavigationAction();
        }
    }
}
