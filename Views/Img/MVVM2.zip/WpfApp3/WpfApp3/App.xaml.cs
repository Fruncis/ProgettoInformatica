﻿using System.Windows;
using WpfApp3.Stores;
using WpfApp3.ViewModels;

namespace WpfApp3
{
    /// <summary>
    /// Logica di interazione per App.xaml
    /// </summary>
    public partial class App : Application
    {//ecco che ho spostato tutta la logica iniziale qua nella classe App
        protected override void OnStartup(StartupEventArgs e)
        {
            MainWindow = new MainWindow()
            {
                DataContext = new MainWindowViewModel() //creo il collegamento tra la view MainWindow (con gli strumenti button, checkbox, ecc.) con il controllore MainWindowViewModel, così riesco a fare il binding
            };

            MainWindow.Show(); //mostra la view MainWindow

            base.OnStartup(e);
        }
    }
}
